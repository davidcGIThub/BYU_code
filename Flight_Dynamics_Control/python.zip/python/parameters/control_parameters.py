import sys
sys.path.append('..')
import numpy as np
import chap5.transfer_function_coef as TF

gravity =
sigma =
Va0 =

#----------roll loop-------------
roll_kp =
roll_kd =

#----------course loop-------------
course_kp =
course_ki =

#----------sideslip loop-------------
sideslip_ki =
sideslip_kp =

#----------yaw damper-------------
yaw_damper_tau_r =
yaw_damper_kp =

#----------pitch loop-------------
pitch_kp =
pitch_kd =
K_theta_DC =

#----------altitude loop-------------
altitude_kp =
altitude_ki =
altitude_zone =

#---------airspeed hold using throttle---------------
airspeed_throttle_kp =
airspeed_throttle_ki =
